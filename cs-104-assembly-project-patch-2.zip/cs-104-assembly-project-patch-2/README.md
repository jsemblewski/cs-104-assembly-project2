CS-104 project 1
================
Writing a `type` program in assembly.

Find the code for your machine's operating system in the appropriately
named directory.
